# Web-Dev-Poe
To acess this file make sure you have xamp installed and you press start on apache and mySQL
You then want to search local host and the folder and file name
This will take you to the offical site
