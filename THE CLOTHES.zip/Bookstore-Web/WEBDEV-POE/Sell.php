
<html>
      <head>
            <title> Ebook Store Home </title>
      </head>

      <body>
              <ul>

                    <li> <a href="Index.php"> Home </a> </li>
                    <li> <a href="About.php"> About </a> </li>
                    <li> <a href="Books.php"> Books for sale! </a> </li>
                    <li> <a href="Sell.php"> Sell your books here! </a> </li>
                    <li> <a href="Login.php"> Login/Signup </a> </li>

             </ul>
              <h1> Ready to sell some books? </h1>



      </body>
</html>
