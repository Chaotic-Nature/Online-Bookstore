
<html>
      <head>
            <title> Ebook Store SignUp </title>
      </head>

      <body>
              <ul>

                    <li> <a href="Index.php"> Home </a> </li>
                    <li> <a href="About.php"> About </a> </li>
                    <li> <a href="Books.php"> Books for sale! </a> </li>
                    <li> <a href="Sell.php"> Sell your books here! </a> </li>
                    <li> <a href="Login.php"> Login/Signup </a> </li>

             </ul>
              <h1> Hello fellow student ! Ready to create your account? </h1>
              <p>  Enter your student details below ! </p>
<form>

<label for="Fname">FirstName</label>
<input type="text" id="Fname" name="Fname" placeholder="...">
</br>

</br>
<label for="Lname">LastName</label>
<input type="text" id="Lname" name="Lname" placeholder="...">
</br>

</br>
<label for="StudentNumber">StudentNumber</label>
<input type="text" id="StudentNumber" name="StudentNumber" placeholder="...">
</br>

</br>
<label for="Password">Password</label>
<input type="text" id="Password" name="Password" placeholder="...">

</br>
<input type="submit">

</form>


      </body>
</html>
