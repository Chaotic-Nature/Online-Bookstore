<html>
<head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <title> EBookStore.com </title>
      <link rel = "stylesheet" href="LoginStyle.css">
       <link rel ="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel = "stylesheet" type ="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/css/bootstrap.min.css">

      </head>

      <body>
            <!--HOME PAGE-->

            <section class ="header">
            <section id="home">

            <nav>
               <input type="checkbox" id="check">

                  <label for ="check" class="checkbtn">
                      <i class="fas fa-bars"></i>
                  </label>  

               <label class = "logo"><b>EBookStore</b></label>   

               <div class="nav-links" id="navLinks">
                    <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                        
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="#About">ABOUT US</a></li>
                        <li><a href="#Our-Work">BOOKS FOR SALE</a></li>
                        <li><a href="#photo-section">SELL YOUR BOOKS HERE</a></li>
                        <li><a href="Login.php">LOGIN/SIGNUP</a></li>

              </ul>

                </div>
                <i class ="fa fa-bars" onclick="showMenu()"></i>

            </nav>
            
            <hr>

              <!--<h1> Login to get started! </h1>
              <p>  Are you a new student looking to sign up? <a href="Signup.php"> click here</a> </br>
              for admin login <a href="AdminLogin.php">click here</a> </p>-->

    <div class = "container">
        <div class = "login-box">
        <div class = "row">
            <div class= "col-md-6 login-left">
                <h2> Login Here </h2>
                <form action = "validation.php" method="post">
                    <div class ="form-group">
                    <label>Username</label>
                    <input type= "text" name="user" class = "form-control" required>
            </div>

            <div class = "form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type = "submit" class = "btn btn-primary"> Login </button>
                </form>
        </div>

        <div class= "col-md-6 login-right">
                <h2> Register Here </h2>
                <form action = "registration.php" method="post">
                    <div class ="form-group">
                    <label>Username</label>
                    <input type= "text" name="user" class = "form-control" required>
            </div>

            <div class = "form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class = "form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type = "submit" class = "btn btn-primary"> Register </button>
                </form>
        </div>
</div>

    </body>
</html>
<!--        
<form>

<label for="StudentNumber">Student Number</label>
<input type="text" id="StudentNumber" name="StudentNumber" placeholder="...">
</br>

</br>
<label for="Password">Password</label>
<input type="text" id="Password" name="Password" placeholder="...">

</br>
 <input type="submit"> 

</form>-->

